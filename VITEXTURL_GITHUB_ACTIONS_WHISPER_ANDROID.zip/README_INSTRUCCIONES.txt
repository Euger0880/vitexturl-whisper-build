VITEXTURL — COMPILACION WHISPER PARA ANDROID ARM64
================================================

OBJETIVO
Compilar libvitext_whisper_jni.so (Android arm64-v8a, API 26) usando
GitHub Actions; no necesita instalar Android NDK en el teléfono.

ARCHIVOS A SUBIR AL REPOSITORIO
Repo: https://github.com/Euger0880/vitexturl-whisper-build

1) vitexturl-whisper-inputs.zip
   SUBIR COMO ARCHIVO BINARIO A LA RAIZ del repositorio.
   No subir el paquete de entrega completo ni descomprimir este ZIP.
   Contiene el mismo codigo fuente whisper.cpp enviado en el chat,
   mas JNI, CMake y el contrato Kotlin.

2) .github/workflows/build-whisper-android.yml
   CREAR EN ESA RUTA EXACTA EN EL REPOSITORIO.
   En la web de GitHub, usar Add file > Create new file,
   escribir como nombre .github/workflows/build-whisper-android.yml,
   pegar el contenido del .yml proporcionado, y hacer commit.
   Primero subir el ZIP binario; despues crear el workflow.

COMO EJECUTAR
Al crear el workflow en la rama main, el disparador push puede ejecutarlo
automaticamente. Alternativamente: GitHub > Actions >
Build VitextURL Whisper Android ARM64 > Run workflow.
Si GitHub muestra Enable workflows/Actions, habilitar para este repositorio.

COMO RECUPERAR LA BIBLIOTECA
GitHub > Actions > ejecucion completada > Artifacts >
vitexturl-whisper-android-arm64 > descargar archivo ZIP.
Adjuntar ese ZIP en esta conversacion. No hace falta abrirlo ni copiar .so.

CONTENIDO ESPERADO DEL ARTEFACTO
jniLibs/arm64-v8a/libvitext_whisper_jni.so
kotlin/com/vitexturl/app/stt/WhisperNative.kt
ELF_HEADER.txt
ELF_DYNAMIC.txt
EXPORTED_SYMBOLS.txt
SHA256SUMS.txt
BUILD_INFO.txt

NOTAS
- El archivo ggml-base.bin NO se sube al repositorio; ronda 142 MiB,
  y el repositorio esta configurado como PUBLICO.
- El workflow usa el NDK r27c en GitHub y verifica SHA256 del ZIP fuente.
- La prueba local confirma que el mismo CMake y JNI compilan bajo Linux,
  pero NO certifica todavia que la compilacion Android vaya a completarse.
- Un archivo .so ARM64 compilado NO demuestra inferencia correcta en el S22:
  la validacion de reconocimiento real se realizara despues en la APK.
- GitHub NO descomprime automaticamente ZIP subidos como archivos.
- GitHub Actions NO requiere permisos de escritura para este workflow.
- Conservar nombres exactos: el workflow valida el nombre y el SHA256.

SI FALLA EL WORKFLOW
Enviar la captura del paso rojo o copiar el error del log. La correccion
se limitara al archivo o etapa que lo cause; no se necesita repetir todo.
